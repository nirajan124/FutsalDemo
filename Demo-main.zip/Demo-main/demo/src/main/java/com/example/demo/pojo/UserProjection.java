package com.example.demo.pojo;

public interface UserProjection {
    Integer getId();

    String getUser_name();

    String getAddress();

    Integer getContact();

}
