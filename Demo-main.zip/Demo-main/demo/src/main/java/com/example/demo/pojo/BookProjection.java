package com.example.demo.pojo;

public interface BookProjection {
    Integer getId();

    Integer getDate();

    String getUserId();

    String getGroundId();

}
